import { X, Music2, Sparkles } from "lucide-react";
import GlassCard from "./GlassCard";
import type { PredictionResult } from "../utils/predictor";

interface PredictionInjectorProps {
  prediction: PredictionResult | null;
  visible: boolean;
  onClose: () => void;
}

export function PredictionInjector({ prediction, visible, onClose }: PredictionInjectorProps) {
  if (!visible || !prediction?.predictedOutcome) return null;

  const isOdd = prediction.predictedOutcome === "Odd";
  return (
    <div className="pred-injector">
      <GlassCard strong glow={isOdd ? "emerald" : "rose"} className="p-3">
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Sparkles size={14} color={isOdd ? "#6ee7b7" : "#fca5a5"} />
          <span style={{ flex: 1, fontSize: 12, fontWeight: 700 }}>
            Next likely:{" "}
            <span className={`oe-pill ${isOdd ? "odd" : "even"}`} style={{ padding: "1px 8px", fontSize: 11 }}>
              {prediction.predictedOutcome}
            </span>
          </span>
          <span style={{ fontSize: 10, color: "rgba(255,255,255,0.45)" }}>{prediction.confidence}%</span>
          <button className="ij-close" onClick={onClose}>
            <X size={11} />
          </button>
        </div>
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginTop: 4 }}>
          {prediction.reasoning}
        </div>
      </GlassCard>
    </div>
  );
}

interface InjectorLauncherProps {
  showMusic: boolean;
  showPred: boolean;
  onToggleMusic: () => void;
  onTogglePred: () => void;
  hasPrediction: boolean;
}

export function InjectorLauncher({ showMusic, showPred, onToggleMusic, onTogglePred, hasPrediction }: InjectorLauncherProps) {
  return (
    <div className="injector-launcher" style={{ bottom: 90, right: 14 }}>
      <button
        className={`btn ${showMusic ? "primary" : ""}`}
        style={{ padding: "6px 10px", borderRadius: 12 }}
        onClick={onToggleMusic}
        title="Toggle music player"
      >
        <Music2 size={14} />
      </button>
      {hasPrediction && (
        <button
          className={`btn ${showPred ? "primary" : ""}`}
          style={{ padding: "6px 10px", borderRadius: 12 }}
          onClick={onTogglePred}
          title="Toggle prediction overlay"
        >
          <Sparkles size={14} />
        </button>
      )}
    </div>
  );
}
