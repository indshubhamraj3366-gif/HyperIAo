import type { K3Record } from "../utils/predictor";

interface TrendChartProps {
  history: K3Record[];
  count?: number;
}

export default function TrendChart({ history, count = 20 }: TrendChartProps) {
  const items = history.slice(0, count).reverse();
  const maxSum = Math.max(...items.map((r) => r.sum), 18);
  const minSum = Math.min(...items.map((r) => r.sum), 3);
  const range = maxSum - minSum || 1;

  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 64, width: "100%" }}>
      {items.map((r, i) => {
        const heightPct = ((r.sum - minSum) / range) * 75 + 10;
        const isOdd = r.singleDouble === "Odd";
        return (
          <div
            key={r.issueNumber + i}
            title={`Sum: ${r.sum} — ${r.singleDouble}`}
            style={{
              flex: 1,
              minWidth: 0,
              height: `${heightPct}%`,
              borderRadius: "4px 4px 0 0",
              background: isOdd
                ? "linear-gradient(to top, #34d399 0%, #6ee7b7 100%)"
                : "linear-gradient(to top, #f87171 0%, #fca5a5 100%)",
              opacity: 0.7 + 0.3 * (i / items.length),
              transition: "height 0.4s ease",
            }}
          />
        );
      })}
    </div>
  );
}
