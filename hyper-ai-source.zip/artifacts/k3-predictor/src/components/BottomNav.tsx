import { LayoutDashboard, Clock, Gamepad2, User } from "lucide-react";
import GlassCard from "./GlassCard";

type Tab = "dashboard" | "history" | "game" | "profile";

interface BottomNavProps {
  tab: Tab;
  setTab: (t: Tab) => void;
}

const tabs: { key: Tab; Icon: typeof LayoutDashboard; label: string }[] = [
  { key: "dashboard", Icon: LayoutDashboard, label: "Home" },
  { key: "history", Icon: Clock, label: "History" },
  { key: "game", Icon: Gamepad2, label: "Game" },
  { key: "profile", Icon: User, label: "Profile" },
];

export default function BottomNav({ tab, setTab }: BottomNavProps) {
  return (
    <div className="bottom-nav-wrap">
      <GlassCard noPad strong className="bottom-nav" style={{ borderRadius: 24 }}>
        {tabs.map(({ key, Icon, label }) => (
          <button
            key={key}
            className={tab === key ? "active" : ""}
            onClick={() => setTab(key)}
          >
            <Icon size={18} />
            <span className="label">{label}</span>
          </button>
        ))}
      </GlassCard>
    </div>
  );
}
