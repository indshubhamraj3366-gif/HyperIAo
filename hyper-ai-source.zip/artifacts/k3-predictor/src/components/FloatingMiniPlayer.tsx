import { useState, useRef, useCallback } from "react";
import { X, Music2, Play, Pause, Volume2, VolumeX, ChevronDown, ChevronUp, SkipBack, SkipForward } from "lucide-react";
import GlassCard from "./GlassCard";

interface FloatingMiniPlayerProps {
  playing: boolean;
  onPlayingChange: (v: boolean) => void;
  onBpmChange?: (bpm: number) => void;
  panelVisible: boolean;
  onPanelClose: () => void;
}

const PLAYLISTS = [
  { id: "1", title: "Lofi Hip Hop 🎵", videoId: "jfKfPfyJRdk" },
  { id: "2", title: "Deep Focus", videoId: "5qap5aO4i9A" },
  { id: "3", title: "Chill Vibes", videoId: "lTRiuFIWV54" },
  { id: "4", title: "Study Music", videoId: "n61ULEU7CO0" },
];

export default function FloatingMiniPlayer({
  playing,
  onPlayingChange,
  onBpmChange,
  panelVisible,
  onPanelClose,
}: FloatingMiniPlayerProps) {
  const [muted, setMuted] = useState(false);
  const [track, setTrack] = useState(0);
  const [expanded, setExpanded] = useState(true);

  const current = PLAYLISTS[track];
  const nextTrack = () => setTrack((t) => (t + 1) % PLAYLISTS.length);
  const prevTrack = () => setTrack((t) => (t - 1 + PLAYLISTS.length) % PLAYLISTS.length);

  // Build YouTube embed URL
  const src = `https://www.youtube-nocookie.com/embed/${current.videoId}?autoplay=1&mute=${muted ? 1 : 0}&loop=1&playlist=${current.videoId}&controls=0&rel=0&iv_load_policy=3&modestbranding=1`;

  // Hidden iframe always mounted when playing — survives panel close
  const hiddenIframe = playing ? (
    <iframe
      key={`${current.videoId}-${muted}`}
      src={src}
      width="1"
      height="1"
      allow="autoplay; encrypted-media"
      title="bg-music"
      style={{ position: "fixed", left: -999, top: -999, opacity: 0, pointerEvents: "none" }}
    />
  ) : null;

  if (!panelVisible) {
    return (
      <>
        {hiddenIframe}
        {/* Minimised bar shown when music is playing but panel is hidden */}
        {playing && (
          <div
            style={{
              position: "fixed",
              bottom: 90,
              right: 14,
              zIndex: 60,
              display: "flex",
              alignItems: "center",
              gap: 8,
              padding: "6px 12px",
              borderRadius: 20,
              background: "rgba(245,200,75,0.12)",
              border: "1px solid rgba(245,200,75,0.25)",
              backdropFilter: "blur(12px)",
              cursor: "pointer",
            }}
            onClick={onPanelClose}
            title="Click to open player"
          >
            <MiniEQ />
            <span style={{ fontSize: 11, color: "var(--gold)", fontWeight: 600, maxWidth: 100, overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>
              {current.title}
            </span>
            <button
              style={{ background: "none", border: "none", padding: 0, cursor: "pointer", color: "rgba(255,255,255,0.5)", display: "flex" }}
              onClick={(e) => { e.stopPropagation(); onPlayingChange(false); }}
            >
              <Pause size={12} />
            </button>
          </div>
        )}
      </>
    );
  }

  return (
    <>
      {hiddenIframe}
      <div className="music-injector">
        <GlassCard strong glow="amber" className="p-3" style={{ minWidth: 230, maxWidth: 280 }}>
          {/* Header row */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: expanded ? 12 : 0 }}>
            {playing ? <MiniEQ /> : <Music2 size={14} color="var(--gold)" />}
            <span style={{ flex: 1, fontSize: 12, fontWeight: 700, color: "var(--gold)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
              {current.title}
            </span>
            <button className="ij-close" onClick={() => setExpanded((e) => !e)}>
              {expanded ? <ChevronDown size={12} /> : <ChevronUp size={12} />}
            </button>
            <button className="ij-close" onClick={onPanelClose} title="Hide panel (music keeps playing)">
              <X size={12} />
            </button>
          </div>

          {expanded && (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {/* Track name display */}
              <div style={{
                padding: "8px 12px",
                borderRadius: 12,
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.06)",
                fontSize: 11,
                color: "rgba(255,255,255,0.6)",
                display: "flex",
                alignItems: "center",
                gap: 8,
              }}>
                <span style={{ fontSize: 9, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", letterSpacing: "0.1em", flexShrink: 0 }}>
                  {PLAYLISTS.indexOf(current) + 1}/{PLAYLISTS.length}
                </span>
                <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{current.title}</span>
              </div>

              {/* Controls */}
              <div style={{ display: "flex", alignItems: "center", gap: 6, justifyContent: "center" }}>
                <button className="btn" style={{ padding: "5px 10px" }} onClick={prevTrack}>
                  <SkipBack size={12} />
                </button>
                <button
                  className="btn primary"
                  style={{ padding: "7px 18px", borderRadius: 20, fontSize: 13 }}
                  onClick={() => onPlayingChange(!playing)}
                >
                  {playing ? <Pause size={14} /> : <Play size={14} />}
                </button>
                <button className="btn" style={{ padding: "5px 10px" }} onClick={nextTrack}>
                  <SkipForward size={12} />
                </button>
                <button className="btn" style={{ padding: "5px 10px" }} onClick={() => setMuted((m) => !m)}>
                  {muted ? <VolumeX size={12} /> : <Volume2 size={12} />}
                </button>
              </div>

              {/* BPM */}
              <div>
                <div style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.12em" }}>
                  Beat Sync BPM
                </div>
                <div style={{ display: "flex", gap: 4 }}>
                  {[80, 100, 120, 140, 160].map((b) => (
                    <button
                      key={b}
                      className="btn"
                      style={{ flex: 1, padding: "3px 0", fontSize: 10, textAlign: "center" }}
                      onClick={() => onBpmChange?.(b)}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>

              {/* Note about background play */}
              <div style={{ fontSize: 9, color: "rgba(255,255,255,0.25)", textAlign: "center", lineHeight: 1.4 }}>
                ✦ Closing this panel keeps music playing
              </div>
            </div>
          )}
        </GlassCard>
      </div>
    </>
  );
}

function MiniEQ() {
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 2, height: 14, flexShrink: 0 }}>
      {[1, 2, 3, 4].map((i) => (
        <div
          key={i}
          style={{
            width: 3,
            borderRadius: 2,
            background: "var(--gold)",
            animation: `eqBar ${200 + i * 80}ms ease-in-out infinite alternate`,
            height: "100%",
            transformOrigin: "bottom",
          }}
        />
      ))}
    </div>
  );
}
