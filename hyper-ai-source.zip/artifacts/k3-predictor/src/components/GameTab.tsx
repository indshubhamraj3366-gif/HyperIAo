import { useState } from "react";
import { ExternalLink, Play, Globe, Youtube, ArrowRight } from "lucide-react";
import GlassCard from "./GlassCard";

function extractYoutubeId(url: string): string | null {
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtube.com")) return u.searchParams.get("v");
    if (u.hostname === "youtu.be") return u.pathname.slice(1);
    return null;
  } catch {
    return null;
  }
}

function normaliseUrl(raw: string): string {
  const s = raw.trim();
  if (!s) return "";
  if (/^https?:\/\//i.test(s)) return s;
  return "https://" + s;
}

const QUICK_LINKS = [
  { label: "Lucky K3", url: "https://www.youtube.com/watch?v=jfKfPfyJRdk", icon: "🎲" },
  { label: "Live Draw", url: "https://www.youtube.com/watch?v=5qap5aO4i9A", icon: "📺" },
  { label: "Strategy", url: "https://www.youtube.com/watch?v=lTRiuFIWV54", icon: "🧠" },
];

export default function GameTab() {
  const [input, setInput] = useState("");
  const [activeUrl, setActiveUrl] = useState("");
  const [embedError, setEmbedError] = useState(false);

  const go = (rawUrl: string = input) => {
    const url = normaliseUrl(rawUrl);
    if (!url) return;
    setEmbedError(false);
    setActiveUrl(url);
  };

  const openExternal = (rawUrl: string = activeUrl) => {
    const url = normaliseUrl(rawUrl || input);
    if (!url) return;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const ytId = activeUrl ? extractYoutubeId(activeUrl) : null;
  const embedSrc = ytId
    ? `https://www.youtube-nocookie.com/embed/${ytId}?autoplay=1&rel=0&modestbranding=1`
    : activeUrl
    ? activeUrl
    : null;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ fontSize: 20, fontWeight: 800, color: "var(--gold)" }}>Game</div>

      {/* URL input */}
      <GlassCard strong glow="amber">
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.15em", marginBottom: 10 }}>
          Paste any link
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <div style={{ flex: 1, position: "relative" }}>
            <Globe
              size={13}
              style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "rgba(255,255,255,0.3)", pointerEvents: "none" }}
            />
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && go()}
              placeholder="youtube.com/watch?v=... or any URL"
              style={{
                width: "100%",
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.12)",
                borderRadius: 12,
                padding: "9px 10px 9px 30px",
                fontSize: 12,
                color: "#fff",
                outline: "none",
              }}
            />
          </div>
          <button className="btn primary" style={{ padding: "9px 14px", borderRadius: 12, flexShrink: 0 }} onClick={() => go()}>
            <ArrowRight size={14} />
          </button>
        </div>

        <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
          <button
            className="btn"
            style={{ flex: 1, fontSize: 11 }}
            onClick={() => go()}
            disabled={!input.trim()}
          >
            <Play size={12} /> Open Here
          </button>
          <button
            className="btn"
            style={{ flex: 1, fontSize: 11 }}
            onClick={() => openExternal(input)}
            disabled={!input.trim()}
          >
            <ExternalLink size={12} /> New Tab
          </button>
        </div>
      </GlassCard>

      {/* Quick links */}
      <GlassCard>
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.15em", marginBottom: 8 }}>Quick Open</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {QUICK_LINKS.map((q) => (
            <div
              key={q.url}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10,
                padding: "8px 12px",
                borderRadius: 12,
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.06)",
                cursor: "pointer",
              }}
              onClick={() => { setInput(q.url); go(q.url); }}
            >
              <span style={{ fontSize: 18 }}>{q.icon}</span>
              <span style={{ flex: 1, fontSize: 13, color: "rgba(255,255,255,0.75)" }}>{q.label}</span>
              <button
                className="btn"
                style={{ padding: "3px 8px", fontSize: 10 }}
                onClick={(e) => { e.stopPropagation(); openExternal(q.url); }}
              >
                <ExternalLink size={10} />
              </button>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Embed / viewer */}
      {embedSrc && !embedError && (
        <GlassCard noPad style={{ overflow: "hidden" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 12px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
            {ytId ? <Youtube size={13} color="#ff4444" /> : <Globe size={13} color="rgba(255,255,255,0.4)" />}
            <span style={{ flex: 1, fontSize: 11, color: "rgba(255,255,255,0.5)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {activeUrl}
            </span>
            <button className="btn" style={{ padding: "2px 8px", fontSize: 10 }} onClick={() => openExternal()}>
              <ExternalLink size={10} /> Open
            </button>
            <button className="ij-close" onClick={() => setActiveUrl("")}>
              <span style={{ fontSize: 12 }}>✕</span>
            </button>
          </div>
          <div style={{ position: "relative", width: "100%", paddingBottom: ytId ? "56.25%" : "70vh", background: "#000" }}>
            <iframe
              key={embedSrc}
              src={embedSrc}
              style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: "none" }}
              allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
              allowFullScreen
              title="game-frame"
              onError={() => setEmbedError(true)}
            />
          </div>
        </GlassCard>
      )}

      {embedError && (
        <GlassCard>
          <div style={{ textAlign: "center", padding: "16px 0" }}>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", marginBottom: 10 }}>
              This site doesn't allow embedding. Open it in a new tab instead.
            </div>
            <button className="btn primary" onClick={() => openExternal()}>
              <ExternalLink size={12} /> Open in New Tab
            </button>
          </div>
        </GlassCard>
      )}

      <div style={{ height: 90 }} />
    </div>
  );
}
