import { useEffect, useRef, memo } from "react";

interface BeatStageProps {
  active: boolean;
  bpm?: number;
}

const BeatStage = memo(function BeatStage({ active, bpm = 120 }: BeatStageProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const timeRef = useRef(0);
  const activeRef = useRef(active);
  const bpmRef = useRef(bpm);

  useEffect(() => { activeRef.current = active; }, [active]);
  useEffect(() => { bpmRef.current = bpm; }, [bpm]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    const BAR_COUNT = 32;
    const bars: number[] = Array.from({ length: BAR_COUNT }, () => Math.random());
    const targets: number[] = [...bars];
    const rings: { r: number; alpha: number; speed: number }[] = [];
    let lastBeat = 0;

    const draw = (ts: number) => {
      rafRef.current = requestAnimationFrame(draw);
      const dt = Math.min(ts - timeRef.current, 50);
      timeRef.current = ts;

      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      if (!activeRef.current) return;

      const beatMs = (60 / bpmRef.current) * 1000;

      // Spawn a ring on each beat
      if (ts - lastBeat > beatMs) {
        lastBeat = ts;
        rings.push({ r: 0, alpha: 0.35, speed: 1.8 + Math.random() * 1.2 });
        // Randomise bar targets on beat
        for (let i = 0; i < BAR_COUNT; i++) {
          targets[i] = 0.1 + Math.random() * 0.9;
        }
      }

      // Lerp bars toward targets
      for (let i = 0; i < BAR_COUNT; i++) {
        bars[i] += (targets[i] - bars[i]) * 0.12;
      }

      // ── Radial rings from center ──────────────────────────
      const cx = w / 2;
      const cy = h / 2;
      for (let j = rings.length - 1; j >= 0; j--) {
        const ring = rings[j];
        ring.r += ring.speed * (dt / 16);
        ring.alpha -= 0.004 * (dt / 16);
        if (ring.alpha <= 0) { rings.splice(j, 1); continue; }

        ctx.beginPath();
        ctx.arc(cx, cy, ring.r * 3, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(245,200,75,${ring.alpha})`;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Second ring slightly offset
        ctx.beginPath();
        ctx.arc(cx, cy, ring.r * 3 * 0.6, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(147,197,253,${ring.alpha * 0.5})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      // ── EQ bars at bottom ──────────────────────────────────
      const barW = Math.floor(w / BAR_COUNT) - 1;
      const maxH = h * 0.38;
      const baseY = h - 90; // above bottom nav

      for (let i = 0; i < BAR_COUNT; i++) {
        const barH = bars[i] * maxH;
        const x = i * (barW + 1);
        const alpha = 0.15 + bars[i] * 0.55;

        // Mirror bar (EQ style)
        const grad = ctx.createLinearGradient(0, baseY, 0, baseY - barH);
        grad.addColorStop(0, `rgba(245,200,75,${alpha * 0.3})`);
        grad.addColorStop(0.6, `rgba(245,200,75,${alpha})`);
        grad.addColorStop(1, `rgba(147,197,253,${alpha})`);
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(x, baseY - barH, barW, barH, [2, 2, 0, 0]);
        ctx.fill();

        // Reflection
        const rGrad = ctx.createLinearGradient(0, baseY, 0, baseY + barH * 0.3);
        rGrad.addColorStop(0, `rgba(245,200,75,${alpha * 0.18})`);
        rGrad.addColorStop(1, `rgba(245,200,75,0)`);
        ctx.fillStyle = rGrad;
        ctx.beginPath();
        ctx.roundRect(x, baseY, barW, barH * 0.3, [0, 0, 2, 2]);
        ctx.fill();
      }

      // ── Top EQ mirror (upside-down, subtle) ───────────────
      const topY = 0;
      for (let i = 0; i < BAR_COUNT; i++) {
        const barH = bars[i] * maxH * 0.45;
        const x = i * (barW + 1);
        const alpha = 0.06 + bars[i] * 0.12;
        const grad = ctx.createLinearGradient(0, topY, 0, topY + barH);
        grad.addColorStop(0, `rgba(147,197,253,${alpha})`);
        grad.addColorStop(1, `rgba(147,197,253,0)`);
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(x, topY, barW, barH, [0, 0, 2, 2]);
        ctx.fill();
      }

      // ── Center glow orb ────────────────────────────────────
      const avgBar = bars.reduce((s, b) => s + b, 0) / BAR_COUNT;
      const orbR = 60 + avgBar * 80;
      const orbGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, orbR);
      orbGrad.addColorStop(0, `rgba(245,200,75,${0.04 + avgBar * 0.06})`);
      orbGrad.addColorStop(1, "rgba(245,200,75,0)");
      ctx.fillStyle = orbGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, orbR, 0, Math.PI * 2);
      ctx.fill();
    };

    rafRef.current = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden
      style={{
        position: "fixed",
        inset: 0,
        pointerEvents: "none",
        zIndex: 1,
        opacity: active ? 1 : 0,
        transition: "opacity 1s ease",
      }}
    />
  );
});

export default BeatStage;
