import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { RefreshCw, TrendingUp, Zap, AlertTriangle, Activity } from "lucide-react";
import GlassCard from "./GlassCard";
import TrendChart from "./TrendChart";
import { calculatePrediction, formatPeriod, incrementIssueNumber, matchIssueNumbers } from "../utils/predictor";
import type { K3Record, PredictionResult } from "../utils/predictor";

interface DashboardProps {
  history: K3Record[];
  loading: boolean;
  error: string | null;
  onRefresh: () => void;
  isFallback?: boolean;
}

const STORAGE_KEY = "k3_predictions_v2";

interface SavedPrediction {
  period: string;
  predictedAt: string;
  predicted: "Odd" | "Even" | null;
  actual: "Odd" | "Even" | null;
  correct: boolean | null;
  confidence: number;
}

function loadSaved(): SavedPrediction[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

function savePredictions(list: SavedPrediction[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list.slice(0, 200)));
}

export default function Dashboard({ history, loading, error, onRefresh, isFallback }: DashboardProps) {
  const [predictions, setPredictions] = useState<SavedPrediction[]>(loadSaved);
  const [now, setNow] = useState(new Date());
  const prevLatestRef = useRef<string>("");

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const latest = history[0] ?? null;
  const prediction: PredictionResult | null = history.length > 3 ? calculatePrediction(history) : null;

  // Save prediction when a new period arrives
  useEffect(() => {
    if (!latest || !prediction) return;
    const curId = String(latest.issueNumber);
    if (curId === prevLatestRef.current) return;

    // Check if previous prediction resolved
    if (prevLatestRef.current) {
      setPredictions((prev) => {
        const updated = prev.map((p) => {
          if (p.actual !== null) return p;
          if (matchIssueNumbers(p.period, curId) || matchIssueNumbers(incrementIssueNumber(p.period), curId)) {
            const correct = p.predicted !== null ? p.predicted === latest.singleDouble : null;
            return { ...p, actual: latest.singleDouble, correct };
          }
          return p;
        });
        savePredictions(updated);
        return updated;
      });
    }

    prevLatestRef.current = curId;

    const nextPeriod = incrementIssueNumber(curId);
    const entry: SavedPrediction = {
      period: nextPeriod,
      predictedAt: new Date().toISOString(),
      predicted: prediction.predictedOutcome,
      actual: null,
      correct: null,
      confidence: prediction.confidence,
    };

    setPredictions((prev) => {
      const deduped = [entry, ...prev.filter((p) => !matchIssueNumbers(p.period, nextPeriod))];
      savePredictions(deduped);
      return deduped;
    });
  }, [latest?.issueNumber]);

  // Countdown to next minute
  const sec = 59 - now.getSeconds();
  const countdownPct = (sec / 59) * 100;
  const isUrgent = sec <= 5;

  const isOdd = latest?.singleDouble === "Odd";
  const predIsOdd = prediction?.predictedOutcome === "Odd";

  // Recent accuracy
  const resolved = predictions.filter((p) => p.correct !== null).slice(0, 20);
  const wins = resolved.filter((p) => p.correct).length;
  const acc = resolved.length > 0 ? Math.round((wins / resolved.length) * 100) : null;

  // Odd/Even ratio last 20
  const last20 = history.slice(0, 20);
  const odds = last20.filter((r) => r.singleDouble === "Odd").length;
  const evens = last20.length - odds;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {/* Orbs */}
      <div className="bg-orb" style={{ width: 300, height: 300, top: -80, right: -80, background: "radial-gradient(circle, rgba(245,200,75,0.08) 0%, transparent 70%)" }} />
      <div className="bg-orb" style={{ width: 260, height: 260, bottom: 100, left: -60, background: "radial-gradient(circle, rgba(59,130,246,0.07) 0%, transparent 70%)" }} />

      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 2 }}>
        <div>
          <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.18em" }}>K3 1-Minute</div>
          <div style={{ fontSize: 22, fontWeight: 900, color: "var(--gold)", letterSpacing: "-0.01em" }}>Hyper AI</div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          {loading && <div className="pulse-dot" style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--gold)" }} />}
          <button className="btn" onClick={onRefresh} disabled={loading}>
            <RefreshCw size={12} className={loading ? "animate-spin" : ""} />
            Refresh
          </button>
        </div>
      </div>

      {isFallback && (
        <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", borderRadius: 12, background: "rgba(245,200,75,0.08)", border: "1px solid rgba(245,200,75,0.2)", fontSize: 12, color: "rgba(245,200,75,0.8)" }}>
          <AlertTriangle size={14} />
          Live API unavailable — showing sandbox data. Predictions are for demo purposes.
        </div>
      )}

      {/* Latest result */}
      <GlassCard glow={isOdd ? "emerald" : "rose"} strong className="scanline">
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.15em", marginBottom: 6 }}>Latest Result</div>
        {latest ? (
          <>
            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", marginBottom: 2, fontFamily: "monospace" }}>
              Period: {formatPeriod(latest.issueNumber)}
            </div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
              <div>
                <span className="huge-num" style={{ fontSize: 48, color: isOdd ? "#6ee7b7" : "#fca5a5" }}>
                  {latest.sum}
                </span>
                <span style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginLeft: 6 }}>SUM</span>
              </div>
              <div style={{ textAlign: "right" }}>
                <span className={`oe-pill ${isOdd ? "odd" : "even"}`} style={{ fontSize: 16, padding: "4px 16px" }}>
                  {latest.singleDouble}
                </span>
                {latest.openCode && (
                  <div style={{ marginTop: 6, fontSize: 12, color: "rgba(255,255,255,0.4)", fontFamily: "monospace" }}>
                    {latest.openCode}
                  </div>
                )}
              </div>
            </div>
          </>
        ) : (
          <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 14, textAlign: "center", padding: "20px 0" }}>
            {loading ? "Loading…" : "No data"}
          </div>
        )}
      </GlassCard>

      {/* Next Period — prominent display */}
      {latest && (
        <GlassCard glow="blue" strong className="scanline">
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.18em" }}>
              Upcoming Period
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
              <div className="pulse-dot" style={{ width: 6, height: 6, borderRadius: "50%", background: isUrgent ? "#f87171" : "#60a5fa" }} />
              <span style={{ fontSize: 10, color: isUrgent ? "#fca5a5" : "rgba(100,180,255,0.8)", fontWeight: 600 }}>
                {String(sec).padStart(2, "0")}s
              </span>
            </div>
          </div>
          <div className="huge-num" style={{ fontSize: 28, color: "#93c5fd", letterSpacing: "0.01em", marginBottom: 6, wordBreak: "break-all" }}>
            {incrementIssueNumber(String(latest.issueNumber))}
          </div>
          <div style={{ height: 4, borderRadius: 2, background: "rgba(255,255,255,0.06)", overflow: "hidden" }}>
            <motion.div
              style={{ height: "100%", borderRadius: 2, background: isUrgent ? "#f87171" : "linear-gradient(to right, #3b82f6, #93c5fd)" }}
              animate={{ width: `${countdownPct}%` }}
              transition={{ duration: 0.8 }}
            />
          </div>
        </GlassCard>
      )}

      {/* Countdown (compact) when no latest */}
      {!latest && (
        <GlassCard glow="blue">
          <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.15em", marginBottom: 8 }}>Next Draw</div>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div>
              <span className="huge-num" style={{ fontSize: 40, color: isUrgent ? "#fca5a5" : "rgba(255,255,255,0.9)", transition: "color 0.3s" }}>
                {String(sec).padStart(2, "0")}
              </span>
              <span style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginLeft: 4 }}>s</span>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ height: 6, borderRadius: 3, background: "rgba(255,255,255,0.06)", overflow: "hidden" }}>
                <motion.div
                  style={{ height: "100%", borderRadius: 3, background: isUrgent ? "#f87171" : "linear-gradient(to right, #3b82f6, #60a5fa)" }}
                  animate={{ width: `${countdownPct}%` }}
                  transition={{ duration: 0.8 }}
                />
              </div>
            </div>
          </div>
        </GlassCard>
      )}

      {/* Prediction */}
      {prediction && (
        <GlassCard glow={predIsOdd ? "emerald" : "rose"} strong>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <Zap size={14} color="var(--gold)" />
            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.15em", flex: 1 }}>
              Prediction — Next Period
            </span>
            {acc !== null && (
              <span style={{ fontSize: 10, color: "rgba(255,255,255,0.35)" }}>
                Acc: {acc}%
              </span>
            )}
          </div>
          {prediction.predictedOutcome ? (
            <>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
                <span className={`oe-pill ${predIsOdd ? "odd" : "even"}`} style={{ fontSize: 22, padding: "6px 24px" }}>
                  {prediction.predictedOutcome}
                </span>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>Confidence</div>
                  <div className="huge-num" style={{ fontSize: 28, color: prediction.confidence >= 70 ? "#6ee7b7" : prediction.confidence >= 55 ? "var(--gold)" : "#fca5a5" }}>
                    {prediction.confidence}%
                  </div>
                </div>
              </div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", marginTop: 8, padding: "6px 10px", borderRadius: 8, background: "rgba(255,255,255,0.04)" }}>
                {prediction.reasoning}
              </div>
            </>
          ) : (
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", padding: "8px 0" }}>
              {prediction.reasoning || "Insufficient pattern data"}
            </div>
          )}
        </GlassCard>
      )}

      {/* Trend chart */}
      {history.length > 4 && (
        <GlassCard glow="amber">
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <TrendingUp size={14} color="var(--gold)" />
            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.15em" }}>
              Trend — Last 20 Draws
            </span>
            <span style={{ marginLeft: "auto", fontSize: 10, color: "rgba(255,255,255,0.3)" }}>
              🟢 {odds}O / 🔴 {evens}E
            </span>
          </div>
          <TrendChart history={history} count={20} />
        </GlassCard>
      )}

      {/* Recent draws mini-table */}
      {history.length > 0 && (
        <GlassCard>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <Activity size={14} color="rgba(255,255,255,0.5)" />
            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.15em" }}>
              Recent Draws
            </span>
          </div>
          <div className="thin-scroll" style={{ overflowX: "auto" }}>
            <table className="k3-table">
              <thead>
                <tr>
                  <th>Period</th>
                  <th>Sum</th>
                  <th>Result</th>
                  <th>Dice</th>
                </tr>
              </thead>
              <tbody>
                {history.slice(0, 8).map((r) => {
                  const odd = r.singleDouble === "Odd";
                  return (
                    <tr key={r.issueNumber}>
                      <td style={{ fontFamily: "monospace", color: "rgba(255,255,255,0.5)", fontSize: 10 }}>
                        {formatPeriod(r.issueNumber)}
                      </td>
                      <td style={{ fontFamily: "monospace", fontWeight: 600 }}>{r.sum}</td>
                      <td>
                        <span className={`oe-pill ${odd ? "odd" : "even"}`} style={{ padding: "1px 7px", fontSize: 9 }}>
                          {r.singleDouble}
                        </span>
                      </td>
                      <td style={{ color: "rgba(255,255,255,0.4)", fontFamily: "monospace" }}>{r.openCode || "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </GlassCard>
      )}

      {/* Accuracy from saved predictions */}
      {resolved.length >= 3 && (
        <GlassCard>
          <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.15em", marginBottom: 8 }}>
            Prediction Accuracy (last {resolved.length})
          </div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
              <span className="huge-num" style={{ fontSize: 32, color: acc! >= 60 ? "#6ee7b7" : acc! >= 45 ? "var(--gold)" : "#fca5a5" }}>{acc}%</span>
              <span style={{ fontSize: 9, color: "rgba(255,255,255,0.3)", textTransform: "uppercase" }}>Overall</span>
            </div>
            <div style={{ flex: 1, display: "flex", alignItems: "flex-end", gap: 2 }}>
              {resolved.slice(0, 20).map((p, i) => (
                <div
                  key={i}
                  title={p.correct === null ? "Pending" : p.correct ? "Correct" : "Wrong"}
                  style={{
                    flex: 1,
                    height: p.correct === null ? 14 : p.correct ? 32 : 16,
                    borderRadius: 3,
                    background: p.correct === null ? "rgba(255,255,255,0.1)" : p.correct ? "#34d399" : "#f87171",
                    opacity: 0.8,
                    transition: "height 0.3s",
                  }}
                />
              ))}
            </div>
          </div>
        </GlassCard>
      )}

      <div style={{ height: 90 }} />
    </div>
  );
}
