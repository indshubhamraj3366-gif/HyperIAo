import { motion } from "framer-motion";
import type { ReactNode } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  glow?: "blue" | "emerald" | "rose" | "amber" | "none";
  strong?: boolean;
  noPad?: boolean;
  style?: React.CSSProperties;
}

export default function GlassCard({
  children,
  className = "",
  glow = "none",
  strong = false,
  noPad = false,
  style,
}: GlassCardProps) {
  const base = strong ? "glass-strong" : "glass";
  const glowClass = glow !== "none" ? `glow-${glow}` : "";
  const pad = noPad ? "" : "p-4";
  return (
    <motion.div
      className={`${base} ${glowClass} ${pad} ${className}`}
      style={style}
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      {children}
    </motion.div>
  );
}
