import { useState } from "react";
import GlassCard from "./GlassCard";
import { ChevronDown, ChevronRight, BookOpen, Cpu, BarChart2 } from "lucide-react";

interface Section {
  icon: typeof BookOpen;
  title: string;
  content: string;
}

const SECTIONS: Section[] = [
  {
    icon: BookOpen,
    title: "What is K3 1-Minute?",
    content:
      "K3 is a fast lottery game where 3 dice are rolled every minute. The SUM of the 3 dice (range 3–18) determines the outcome. If the sum is odd (3,5,7,9,11,13,15,17), the result is 'Odd'. If the sum is even (4,6,8,10,12,14,16,18), the result is 'Even'.",
  },
  {
    icon: Cpu,
    title: "How the Predictor Works",
    content:
      "This app fetches up to 500 historical K3 draws and uses SUM-pattern matching. For the latest draw's SUM, it scans all 500 records to find past occurrences of the same SUM, then looks at what result followed each occurrence. If 55%+ of those next-results agree (Odd or Even), that becomes the prediction.",
  },
  {
    icon: BarChart2,
    title: "Reading the Confidence Score",
    content:
      "Confidence = percentage of matching historical next-results that agree with the prediction. ≥70% = high confidence (green). 55–69% = moderate (gold). Below 55% = insufficient pattern (no prediction shown). More matches = more reliable statistic.",
  },
];

const FAQ: { q: string; a: string }[] = [
  {
    q: "Why does the prediction sometimes not show?",
    a: "The current SUM needs at least 3 historical matches AND a 55%+ majority in next-results. If the SUM is rare or outcomes are split, the predictor shows nothing rather than guessing randomly.",
  },
  {
    q: "How often does data refresh?",
    a: "The app polls the API every 2 seconds. It also triggers extra fetches near the 0-second mark (when a new period begins).",
  },
  {
    q: "Why 500 results and not more?",
    a: "500 results gives roughly 8+ hours of 1-minute data. Going further risks including outdated patterns from very different market conditions, which can reduce accuracy. 500 is a good balance of recency and statistical depth.",
  },
  {
    q: "Is this guaranteed to be accurate?",
    a: "No. K3 is a random game. Pattern matching finds statistical tendencies in historical data, but each draw is independent. Use this as a tool for insight, not as a guarantee.",
  },
];

export default function Info() {
  const [openSection, setOpenSection] = useState<number | null>(0);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ fontSize: 20, fontWeight: 800, color: "var(--gold)" }}>Info</div>

      {/* Explainer sections */}
      {SECTIONS.map((s, i) => {
        const open = openSection === i;
        const { icon: Icon } = s;
        return (
          <GlassCard key={i} noPad>
            <button
              className="info-toggle"
              style={{ width: "100%", textAlign: "left" }}
              onClick={() => setOpenSection(open ? null : i)}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <Icon size={14} color="var(--gold)" />
                <span style={{ fontSize: 13, fontWeight: 600 }}>{s.title}</span>
              </div>
              {open ? <ChevronDown size={14} color="rgba(255,255,255,0.4)" /> : <ChevronRight size={14} color="rgba(255,255,255,0.4)" />}
            </button>
            {open && (
              <div style={{ padding: "0 14px 14px", fontSize: 13, color: "rgba(255,255,255,0.6)", lineHeight: 1.6 }}>
                {s.content}
              </div>
            )}
          </GlassCard>
        );
      })}

      {/* Dice reference */}
      <GlassCard glow="amber">
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.15em", marginBottom: 10 }}>
          Sum Reference Chart
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
          {Array.from({ length: 16 }, (_, i) => i + 3).map((sum) => {
            const isOdd = sum % 2 !== 0;
            return (
              <div
                key={sum}
                className={`oe-pill ${isOdd ? "odd" : "even"}`}
                style={{ padding: "3px 8px", fontSize: 11, minWidth: 36, justifyContent: "center" }}
              >
                {sum}
              </div>
            );
          })}
        </div>
        <div style={{ marginTop: 8, fontSize: 11, color: "rgba(255,255,255,0.35)" }}>
          🟢 Odd sums: 3, 5, 7, 9, 11, 13, 15, 17 &nbsp;|&nbsp; 🔴 Even sums: 4, 6, 8, 10, 12, 14, 16, 18
        </div>
      </GlassCard>

      {/* FAQ */}
      <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginTop: 4 }}>FAQ</div>
      {FAQ.map((faq, i) => {
        const open = openFaq === i;
        return (
          <GlassCard key={i} noPad>
            <button
              className="info-toggle"
              style={{ width: "100%", textAlign: "left" }}
              onClick={() => setOpenFaq(open ? null : i)}
            >
              <span style={{ fontSize: 12, fontWeight: 500, color: "rgba(255,255,255,0.8)" }}>{faq.q}</span>
              {open ? <ChevronDown size={13} color="rgba(255,255,255,0.4)" /> : <ChevronRight size={13} color="rgba(255,255,255,0.4)" />}
            </button>
            {open && (
              <div style={{ padding: "0 14px 14px", fontSize: 12, color: "rgba(255,255,255,0.5)", lineHeight: 1.6 }}>
                {faq.a}
              </div>
            )}
          </GlassCard>
        );
      })}

      <div style={{ height: 90 }} />
    </div>
  );
}
