import { useState } from "react";
import GlassCard from "./GlassCard";
import { Play, Pause, Music2, SkipForward, SkipBack, Volume2, VolumeX, Zap, Info, ChevronDown, ChevronRight } from "lucide-react";

interface ProfileProps {
  playing: boolean;
  onPlayingChange: (v: boolean) => void;
  onToggleMusicPanel: () => void;
  onBpmChange: (b: number) => void;
  bpm: number;
}

const ABOUT_ITEMS: { q: string; a: string }[] = [
  {
    q: "What is Hyper AI?",
    a: "Hyper AI is a real-time K3 1-Minute lottery predictor. It fetches live draw history and uses SUM-pattern matching across up to 500 records to forecast whether the next result will be Odd or Even.",
  },
  {
    q: "How accurate is it?",
    a: "Accuracy varies. The algorithm finds statistical tendencies — if a SUM appeared 10 times historically and 7 of those were followed by 'Odd', confidence is 70%. But each draw is random; no prediction is guaranteed.",
  },
  {
    q: "Why does the beat visualizer appear?",
    a: "The Beat Sync visualiser is a fun ambient animation tied to background music. It creates EQ bar animations and radial pulse rings synced to the selected BPM. Toggle music in this tab to activate it.",
  },
  {
    q: "What is the Game tab?",
    a: "The Game tab lets you paste any web or YouTube URL and view it directly inside the app, or open it in a new tab. Use it to watch live draws, strategy videos, or any web content.",
  },
];

export default function Profile({ playing, onPlayingChange, onToggleMusicPanel, onBpmChange, bpm }: ProfileProps) {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [activeBpm, setActiveBpm] = useState(bpm);

  const handleBpm = (b: number) => {
    setActiveBpm(b);
    onBpmChange(b);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ fontSize: 20, fontWeight: 800, color: "var(--gold)" }}>Profile</div>

      {/* ── Music Controls ── */}
      <GlassCard strong glow="amber">
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
          <Music2 size={14} color="var(--gold)" />
          <span style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.15em" }}>
            Music &amp; Beat Sync
          </span>
        </div>

        {/* Play / Open player */}
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          <button
            className={`btn ${playing ? "primary" : ""}`}
            style={{ flex: 1, padding: "10px 0", fontSize: 13, borderRadius: 14, justifyContent: "center" }}
            onClick={() => onPlayingChange(!playing)}
          >
            {playing ? <><Pause size={14} /> Pause</> : <><Play size={14} /> Play Music</>}
          </button>
          <button
            className="btn"
            style={{ padding: "10px 14px", borderRadius: 14 }}
            onClick={onToggleMusicPanel}
          >
            <Music2 size={14} />
          </button>
        </div>

        {/* BPM selector */}
        <div>
          <div style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.12em" }}>
            Beat Sync BPM
          </div>
          <div style={{ display: "flex", gap: 5 }}>
            {[80, 100, 120, 140, 160].map((b) => (
              <button
                key={b}
                className={`btn ${activeBpm === b ? "primary" : ""}`}
                style={{ flex: 1, padding: "5px 0", fontSize: 10, textAlign: "center", justifyContent: "center" }}
                onClick={() => handleBpm(b)}
              >
                {b}
              </button>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* ── Beat Sync toggle visual ── */}
      {playing && (
        <GlassCard glow="blue">
          <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.15em", marginBottom: 10 }}>
            Beat Sync Active
          </div>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 40, justifyContent: "center" }}>
            {Array.from({ length: 20 }, (_, i) => (
              <div
                key={i}
                style={{
                  width: 6,
                  borderRadius: 3,
                  background: i % 2 === 0 ? "var(--gold)" : "#93c5fd",
                  animation: `eqBar ${300 + i * 40}ms ease-in-out infinite alternate`,
                  height: "100%",
                  transformOrigin: "bottom",
                  opacity: 0.7 + 0.3 * Math.sin(i),
                }}
              />
            ))}
          </div>
          <div style={{ fontSize: 9, color: "rgba(255,255,255,0.25)", textAlign: "center", marginTop: 8 }}>
            {activeBpm} BPM · Visualiser active on all screens
          </div>
        </GlassCard>
      )}

      {/* ── About / FAQ ── */}
      <GlassCard>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
          <Info size={14} color="rgba(255,255,255,0.5)" />
          <span style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.15em" }}>
            About Hyper AI
          </span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
          {ABOUT_ITEMS.map((item, i) => {
            const open = openFaq === i;
            return (
              <div key={i}>
                <button
                  onClick={() => setOpenFaq(open ? null : i)}
                  style={{
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    gap: 8,
                    padding: "10px 0",
                    background: "none",
                    border: "none",
                    borderBottom: i < ABOUT_ITEMS.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none",
                    color: "rgba(255,255,255,0.75)",
                    fontSize: 12,
                    fontWeight: 500,
                    cursor: "pointer",
                    textAlign: "left",
                  }}
                >
                  {item.q}
                  {open ? <ChevronDown size={13} color="rgba(255,255,255,0.3)" /> : <ChevronRight size={13} color="rgba(255,255,255,0.3)" />}
                </button>
                {open && (
                  <div style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", lineHeight: 1.6, paddingBottom: 10 }}>
                    {item.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </GlassCard>

      {/* ── App info ── */}
      <GlassCard>
        <div style={{ textAlign: "center", padding: "8px 0" }}>
          <div style={{ fontSize: 22, fontWeight: 900, color: "var(--gold)", marginBottom: 4 }}>Hyper AI</div>
          <div style={{ fontSize: 11, color: "rgba(255,255,255,0.3)" }}>K3 1-Minute Predictor</div>
          <div style={{ fontSize: 10, color: "rgba(255,255,255,0.2)", marginTop: 8 }}>
            Pattern matching · 500-record depth · Real-time polling
          </div>
        </div>
      </GlassCard>

      <div style={{ height: 90 }} />
    </div>
  );
}
