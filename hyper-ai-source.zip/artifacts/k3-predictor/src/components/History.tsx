import { useState } from "react";
import { Search } from "lucide-react";
import GlassCard from "./GlassCard";
import { formatPeriod } from "../utils/predictor";
import type { K3Record } from "../utils/predictor";

interface HistoryProps {
  history: K3Record[];
}

export default function History({ history }: HistoryProps) {
  const [filter, setFilter] = useState<"all" | "Odd" | "Even">("all");
  const [search, setSearch] = useState("");

  const filtered = history.filter((r) => {
    if (filter !== "all" && r.singleDouble !== filter) return false;
    if (search.trim()) {
      const s = search.trim().toLowerCase();
      if (!String(r.issueNumber).includes(s) && !String(r.sum).includes(s)) return false;
    }
    return true;
  });

  const oddCount = history.filter((r) => r.singleDouble === "Odd").length;
  const evenCount = history.length - oddCount;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ fontSize: 20, fontWeight: 800, color: "var(--gold)" }}>History</div>

      {/* Stats */}
      <GlassCard className="p-3">
        <div style={{ display: "flex", gap: 12, justifyContent: "space-around" }}>
          <div style={{ textAlign: "center" }}>
            <div className="huge-num" style={{ fontSize: 28 }}>{history.length}</div>
            <div style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Total</div>
          </div>
          <div style={{ textAlign: "center" }}>
            <div className="huge-num" style={{ fontSize: 28, color: "#6ee7b7" }}>{oddCount}</div>
            <div style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Odd</div>
          </div>
          <div style={{ textAlign: "center" }}>
            <div className="huge-num" style={{ fontSize: 28, color: "#fca5a5" }}>{evenCount}</div>
            <div style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Even</div>
          </div>
          <div style={{ textAlign: "center" }}>
            <div className="huge-num" style={{ fontSize: 28 }}>
              {history.length > 0 ? Math.round((oddCount / history.length) * 100) : 0}%
            </div>
            <div style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", textTransform: "uppercase" }}>Odd%</div>
          </div>
        </div>
      </GlassCard>

      {/* Filters */}
      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
        {(["all", "Odd", "Even"] as const).map((f) => (
          <button
            key={f}
            className={`btn ${filter === f ? "primary" : ""}`}
            style={{ flex: 1 }}
            onClick={() => setFilter(f)}
          >
            {f === "all" ? "All" : f}
          </button>
        ))}
        <div style={{ flex: 2, position: "relative" }}>
          <Search size={12} style={{ position: "absolute", left: 8, top: "50%", transform: "translateY(-50%)", color: "rgba(255,255,255,0.35)" }} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search period / sum…"
            style={{
              width: "100%",
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 10,
              padding: "6px 8px 6px 26px",
              fontSize: 11,
              color: "#fff",
              outline: "none",
            }}
          />
        </div>
      </div>

      {/* Table */}
      <GlassCard noPad>
        <div className="thin-scroll" style={{ overflowY: "auto", maxHeight: "60dvh" }}>
          <table className="k3-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Period</th>
                <th>Sum</th>
                <th>Result</th>
                <th>Dice</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r, i) => {
                const isOdd = r.singleDouble === "Odd";
                return (
                  <tr key={r.issueNumber}>
                    <td style={{ color: "rgba(255,255,255,0.3)", fontSize: 10 }}>{i + 1}</td>
                    <td style={{ fontFamily: "monospace", color: "rgba(255,255,255,0.5)", fontSize: 10 }}>
                      {formatPeriod(r.issueNumber)}
                    </td>
                    <td style={{ fontFamily: "monospace", fontWeight: 600 }}>{r.sum}</td>
                    <td>
                      <span className={`oe-pill ${isOdd ? "odd" : "even"}`} style={{ padding: "1px 7px", fontSize: 9 }}>
                        {r.singleDouble}
                      </span>
                    </td>
                    <td style={{ color: "rgba(255,255,255,0.4)", fontFamily: "monospace", fontSize: 10 }}>
                      {r.openCode || "—"}
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={5} style={{ textAlign: "center", color: "rgba(255,255,255,0.25)", padding: "24px 0" }}>
                    No records found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </GlassCard>

      <div style={{ height: 90 }} />
    </div>
  );
}
