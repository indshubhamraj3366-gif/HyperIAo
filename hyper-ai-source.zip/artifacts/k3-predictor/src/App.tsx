import { useState, useEffect, useRef, useCallback } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Dashboard from "./components/Dashboard";
import History from "./components/History";
import GameTab from "./components/GameTab";
import Profile from "./components/Profile";
import BottomNav from "./components/BottomNav";
import BeatStage from "./components/BeatStage";
import FloatingMiniPlayer from "./components/FloatingMiniPlayer";
import { fetchK3History } from "./api/k3";
import type { K3Record } from "./utils/predictor";

const HISTORY_CACHE_KEY = "k3_history_cache_v1";
const MAX_HISTORY = 500;

type Tab = "dashboard" | "history" | "game" | "profile";

function loadCachedHistory(): K3Record[] {
  try {
    const raw = localStorage.getItem(HISTORY_CACHE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as K3Record[];
  } catch { return []; }
}

function mergeHistory(existing: K3Record[], incoming: K3Record[]): K3Record[] {
  const seen = new Set<string>();
  const merged: K3Record[] = [];
  for (const r of [...incoming, ...existing]) {
    const key = String(r.issueNumber);
    if (!seen.has(key)) { seen.add(key); merged.push(r); }
  }
  merged.sort((a, b) => String(b.issueNumber).localeCompare(String(a.issueNumber)));
  return merged.slice(0, MAX_HISTORY);
}

export default function App() {
  const [tab, setTab] = useState<Tab>("dashboard");
  const [history, setHistory] = useState<K3Record[]>(loadCachedHistory);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isFallback, setIsFallback] = useState(false);

  // Music — lifted so state survives tab/panel open/close
  const [musicPlaying, setMusicPlaying] = useState(false);
  const [musicPanelVisible, setMusicPanelVisible] = useState(false);
  const [bpm, setBpm] = useState(120);

  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const mountedRef = useRef(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchK3History();
      if (mountedRef.current && res.data.length > 0) {
        setIsFallback(res.isFallback);
        setHistory((prev) => {
          const merged = mergeHistory(prev, res.data);
          try { localStorage.setItem(HISTORY_CACHE_KEY, JSON.stringify(merged)); } catch { /**/ }
          return merged;
        });
      }
    } catch (e: unknown) {
      if (mountedRef.current) setError(e instanceof Error ? e.message : "Fetch failed");
    } finally {
      if (mountedRef.current) setLoading(false);
    }
  }, []);

  // Poll every 2 seconds
  useEffect(() => {
    mountedRef.current = true;
    fetchData();
    pollingRef.current = setInterval(fetchData, 2000);
    return () => {
      mountedRef.current = false;
      if (pollingRef.current) clearInterval(pollingRef.current);
    };
  }, [fetchData]);

  const tabVariants = {
    initial: { opacity: 0, x: 8 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -8 },
  };

  return (
    <div className="App" style={{ minHeight: "100dvh", position: "relative", overflowX: "hidden" }}>
      {/* Beat visualiser canvas — fixed behind everything */}
      <BeatStage active={musicPlaying} bpm={bpm} />

      {/* Floating music player — always rendered so iframe survives panel close */}
      <FloatingMiniPlayer
        playing={musicPlaying}
        onPlayingChange={setMusicPlaying}
        onBpmChange={setBpm}
        panelVisible={musicPanelVisible}
        onPanelClose={() => setMusicPanelVisible((v) => !v)}
      />

      {/* Page content */}
      <div style={{ position: "relative", zIndex: 2, padding: "16px 16px 0", maxWidth: 480, margin: "0 auto" }}>
        <AnimatePresence mode="wait">
          {tab === "dashboard" && (
            <motion.div key="dashboard" variants={tabVariants} initial="initial" animate="animate" exit="exit" transition={{ duration: 0.18 }}>
              <Dashboard
                history={history}
                loading={loading}
                error={error}
                onRefresh={fetchData}
                isFallback={isFallback}
              />
            </motion.div>
          )}
          {tab === "history" && (
            <motion.div key="history" variants={tabVariants} initial="initial" animate="animate" exit="exit" transition={{ duration: 0.18 }}>
              <History history={history} />
            </motion.div>
          )}
          {tab === "game" && (
            <motion.div key="game" variants={tabVariants} initial="initial" animate="animate" exit="exit" transition={{ duration: 0.18 }}>
              <GameTab />
            </motion.div>
          )}
          {tab === "profile" && (
            <motion.div key="profile" variants={tabVariants} initial="initial" animate="animate" exit="exit" transition={{ duration: 0.18 }}>
              <Profile
                playing={musicPlaying}
                onPlayingChange={setMusicPlaying}
                onToggleMusicPanel={() => setMusicPanelVisible((v) => !v)}
                onBpmChange={setBpm}
                bpm={bpm}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <BottomNav tab={tab} setTab={setTab} />
    </div>
  );
}
