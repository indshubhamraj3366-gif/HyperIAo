import type { K3Record } from "../utils/predictor";

/** Generate realistic K3 sandbox records starting from a base issue number */
function genRecords(baseIssueNum: bigint, count: number): K3Record[] {
  const records: K3Record[] = [];
  // Seeded pseudo-random for consistency
  let seed = Number(baseIssueNum % 999983n);
  const rng = () => { seed = (seed * 1664525 + 1013904223) & 0x7fffffff; return seed / 0x7fffffff; };
  const dice = () => Math.floor(rng() * 6) + 1;

  for (let i = 0; i < count; i++) {
    const d1 = dice(), d2 = dice(), d3 = dice();
    const sum = d1 + d2 + d3;
    const issueNumber = String(baseIssueNum - BigInt(i));
    records.push({
      issueNumber,
      sum,
      singleDouble: sum % 2 !== 0 ? "Odd" : "Even",
      openCode: `${d1},${d2},${d3}`,
    });
  }
  return records;
}

/** Build today's approximate base issue number from the current date + time */
function todayBase(): bigint {
  const now = new Date();
  const y = now.getUTCFullYear();
  const m = String(now.getUTCMonth() + 1).padStart(2, "0");
  const d = String(now.getUTCDate()).padStart(2, "0");
  // Approximate 1-min periods elapsed today
  const elapsed = now.getUTCHours() * 60 + now.getUTCMinutes();
  const seq = String(elapsed + 1).padStart(4, "0");
  return BigInt(`${y}${m}${d}${seq}`);
}

export function getFallbackHistory(): K3Record[] {
  return genRecords(todayBase(), 200);
}
