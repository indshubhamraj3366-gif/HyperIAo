import type { K3Record } from "../utils/predictor";
import { getFallbackHistory } from "./fallback";

const BACKEND_URL = "https://draw-history-predict.preview.emergentagent.com";
const API = `${BACKEND_URL}/api`;

interface K3HistoryResponse {
  data: K3Record[];
  isFallback: boolean;
  stale?: boolean;
}

/**
 * Fetch the latest K3 1M history.
 * Falls back to realistic sandbox data if the upstream API is unreachable.
 */
export async function fetchK3History(): Promise<K3HistoryResponse> {
  try {
    const url = `${API}/history`;
    const res = await fetch(url, {
      signal: AbortSignal.timeout(8000),
      headers: { Accept: "application/json" },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();

    const list: K3Record[] = Array.isArray(json)
      ? json
      : Array.isArray(json.data)
      ? json.data
      : [];

    if (list.length === 0) throw new Error("Empty response");

    return { data: list, isFallback: false };
  } catch {
    // Upstream unavailable — return realistic sandbox data
    return { data: getFallbackHistory(), isFallback: true };
  }
}
