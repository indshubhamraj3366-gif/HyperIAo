export interface K3Record {
  issueNumber: string;
  sum: number;
  singleDouble: "Odd" | "Even";
  openCode?: string;
}

export interface PatternMatch {
  matchIssue: string;
  matchSum: number;
  nextIssue: string;
  nextSum: number;
  nextOutcome: "Odd" | "Even";
}

export interface PredictionResult {
  predictedOutcome: "Odd" | "Even" | null;
  matches: PatternMatch[];
  confidence: number;
  reasoning: string;
  totalMatches: number;
}

/**
 * K3 1-Min Prediction Logic — SUM-Pattern matching against last 500 results.
 *
 * Rules:
 *  1. Take the latest SUM as the "target pattern".
 *  2. Scan ALL history (up to 500 records) for records whose SUM equals the target.
 *  3. For each match, record the "next result" (the draw that came right after).
 *  4. If majority of those next-results agree on Odd or Even → Prediction = majority.
 *  5. Need at least 3 matches and a 60%+ majority for a confident prediction.
 */
export function calculatePrediction(history: K3Record[]): PredictionResult {
  if (!history || history.length < 4) {
    return {
      predictedOutcome: null,
      matches: [],
      confidence: 0,
      reasoning: "Not enough history",
      totalMatches: 0,
    };
  }

  const latest = history[0];
  const targetSum = latest.sum;

  // Scan ALL records in history (up to 500) for same-SUM matches
  const allMatches: PatternMatch[] = [];
  for (let i = 1; i < history.length; i++) {
    if (history[i].sum === targetSum) {
      const next = history[i - 1]; // record that came right after this match in time
      if (!next) continue;
      allMatches.push({
        matchIssue: history[i].issueNumber,
        matchSum: history[i].sum,
        nextIssue: next.issueNumber,
        nextSum: next.sum,
        nextOutcome: next.singleDouble,
      });
    }
  }

  const totalMatches = allMatches.length;

  if (totalMatches < 3) {
    return {
      predictedOutcome: null,
      matches: allMatches.slice(0, 3),
      confidence: 0,
      reasoning: `Only ${totalMatches} match${totalMatches === 1 ? "" : "es"} for SUM ${targetSum} in ${history.length} records. Need ≥3.`,
      totalMatches,
    };
  }

  const oddVotes = allMatches.filter((m) => m.nextOutcome === "Odd").length;
  const evenVotes = allMatches.filter((m) => m.nextOutcome === "Even").length;
  const majority = Math.max(oddVotes, evenVotes);
  const majorityPct = Math.round((majority / totalMatches) * 100);

  let predictedOutcome: "Odd" | "Even" | null = null;
  if (oddVotes > evenVotes && majorityPct >= 55) predictedOutcome = "Odd";
  else if (evenVotes > oddVotes && majorityPct >= 55) predictedOutcome = "Even";

  if (!predictedOutcome) {
    return {
      predictedOutcome: null,
      matches: allMatches.slice(0, 3),
      confidence: 0,
      reasoning: `Split: ${oddVotes}O / ${evenVotes}E from ${totalMatches} matches. No clear majority.`,
      totalMatches,
    };
  }

  const confidence = majorityPct;
  return {
    predictedOutcome,
    matches: allMatches.slice(0, 3),
    confidence,
    reasoning: `SUM ${targetSum}: ${oddVotes}O / ${evenVotes}E across ${totalMatches} historical matches`,
    totalMatches,
  };
}

/** Increment numeric issue number (supports very large ids). */
export function incrementIssueNumber(issueStr: string): string {
  if (!issueStr) return issueStr;
  if (/^\d+$/.test(issueStr)) {
    try {
      return (BigInt(issueStr) + 1n).toString();
    } catch (_) {
      // fall through
    }
  }
  const m = String(issueStr).match(/^(.*?)(\d+)$/);
  if (m) {
    const prefix = m[1];
    const suffix = m[2];
    const next = (BigInt(suffix) + 1n).toString();
    return prefix + next.padStart(suffix.length, "0");
  }
  return issueStr + "_1";
}

/**
 * Strict issue-number match — equal strings, equal numeric content,
 * or one being a suffix of the other (>= 6 digits).
 */
export function matchIssueNumbers(a: string | number, b: string | number): boolean {
  const sa = String(a).trim();
  const sb = String(b).trim();
  if (sa === sb) return true;
  const da = sa.replace(/\D/g, "");
  const db = sb.replace(/\D/g, "");
  if (!da || !db) return false;
  if (da === db) return true;
  if (da.length === db.length) return false;
  const shorter = da.length < db.length ? da : db;
  const longer = da.length < db.length ? db : da;
  if (shorter.length >= 6 && longer.endsWith(shorter)) return true;
  return false;
}

/** Format a period/issue number for display. */
export function formatPeriod(issueStr: string | number): string {
  const s = String(issueStr);
  // If it looks like a date-prefixed number (e.g. 20250630001234), format nicely
  if (s.length >= 12 && /^\d+$/.test(s)) {
    const datePart = s.slice(0, 8); // YYYYMMDD
    const seqPart = s.slice(8);     // sequence
    const year = datePart.slice(0, 4);
    const month = datePart.slice(4, 6);
    const day = datePart.slice(6, 8);
    return `${year}-${month}-${day} #${seqPart.replace(/^0+/, "") || "0"}`;
  }
  return s;
}

/** Derive Odd/Even from a numeric sum. */
export function sumToOddEven(sum: number): "Odd" | "Even" {
  return Number(sum) % 2 === 0 ? "Even" : "Odd";
}
